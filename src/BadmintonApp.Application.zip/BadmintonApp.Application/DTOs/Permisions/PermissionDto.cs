﻿using System;

namespace BadmintonApp.Application.DTOs.Permisions;

public class PermissionDto
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}

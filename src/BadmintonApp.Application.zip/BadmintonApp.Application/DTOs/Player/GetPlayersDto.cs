﻿namespace BadmintonApp.Application.DTOs.Player;

public class GetPlayersDto
{
    public int Page { get; set; }
    public int PerPage { get; set; }
}

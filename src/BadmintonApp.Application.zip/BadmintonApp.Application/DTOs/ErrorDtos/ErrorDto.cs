﻿namespace BadmintonApp.Application.DTOs.ErrorDtos;

public class ErrorDto
{
    public string Message { get; set; } = string.Empty;
}
